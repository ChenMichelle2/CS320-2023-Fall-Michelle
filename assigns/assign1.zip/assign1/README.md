# CS320-2023-Fall

## Assign1: the 1st assignment

- Out: Thu, the 14th of September at 12:00am
- Due: Wed, the 20th of September at 11:59pm

### assign1.ml

The description of Assign1 is given in the
file assign1.ml. If you are unclear about
what is asked of you to do in this assignment,
please make sure that you seek clarification
before proceeding.

### Testing

This is a directory for the class.  Some testing code for Assign1 may
be stored here. There may or may not be such a directory for the future
assignments.

### MySolution

This is a directory for you. Please store in this directory all the
code that you want to turn in. Your submitted files should be named
as follows:

1. MySolution/assign1-1.ml // containing your solution to assign1-1
2. MySolution/assign1-2.ml // containing your solution to assign1-2
3. MySolution/assign1-3.ml // containing your solution to assign1-3
4. MySolution/assign1-4.ml // containing your solution to assign1-4
5. MySolution/assign1-5.ml // containing your solution to assign1-5
6. MySolution/assign1-6.ml // containing your solution to assign1-6 // bonus
