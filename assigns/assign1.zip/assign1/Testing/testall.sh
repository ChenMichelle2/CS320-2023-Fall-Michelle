#!/bin/sh

ocaml < assign1-1-test.ml
ocaml < assign1-2-test.ml
ocaml < assign1-3-test.ml
ocaml < assign1-4-test.ml
ocaml < assign1-5-test.ml
ocaml < assign1-6-test.ml

###### end of [testall.sh] ######
